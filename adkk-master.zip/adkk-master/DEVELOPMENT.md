# ADK多智能体文档处理系统开发文档

## 项目结构

```
adk/
├── data_agent/                          # 会议纪要信息提取模块
│   ├── __init__.py
│   ├── agent.py                         # 智能体定义和主逻辑
│   ├── agent_prompt.yaml                # 系统提示词
│   └── .env                             # 环境变量配置
├── second_paragragh_write/              # 文档第二章节生成模块
│   ├── __init__.py
│   ├── client.py                        # Dify API客户端
│   ├── write_agent.py                   # 智能体定义和主逻辑
│   ├── write_agent_prompt.yaml          # 系统提示词
│   └── .env                             # 环境变量配置
├── text_agent/                          # 文档编写流程控制模块
│   ├── __init__.py
│   ├── agent.py                         # 智能体定义和主逻辑
│   ├── README.md                        # 模块说明
│   └── .env                             # 环境变量配置
├── README.md                            # 项目总体说明
└── DEVELOPMENT.md                       # 开发文档
```

## 模块详细设计

### data_agent模块

#### 核心组件

1. **Agent定义** (`agent.py`)
   - 使用`Agent`类创建核心智能体
   - 集成`PlanReActPlanner`规划器
   - 注册`read_file`和`write_file`工具

2. **Prompt设计** (`agent_prompt.yaml`)
   - 明确定义角色为"会议纪要信息提取与结构化处理专家"
   - 详细说明6个必须提取的字段
   - 提供客户体系分类和目标产品范围参考
   - 定义严格的JSON输出格式

#### 关键代码解析

```python
# 智能体初始化
root_agent = Agent(  
    name="纪要分析智能体",  
    model=model,
    planner=PlanReActPlanner(),
    description="按顺序执行文档读取和写入的完整工作流",  
    instruction=system_prompt,
    tools=[write_file, read_file] 
)

# 工具函数实现
def read_file(filename: str) -> str:
    """读取文件内容并返回文本"""
    with open(filename, "r", encoding="utf-8") as file:
        content = file.read()
    return content
```

### second_paragragh_write模块

#### 核心组件

1. **Agent定义** (`write_agent.py`)
   - 使用`Agent`类创建第二章节编写智能体
   - 注册`retrieve`知识库检索工具

2. **Dify客户端** (`client.py`)
   - 实现Dify数据集API的封装
   - 支持GET、POST、PUT、DELETE方法
   - 处理认证和错误响应

3. **Prompt设计** (`write_agent_prompt.yaml`)
   - 定义三步工作流程：内容分析→内容检索→内容改写
   - 详细说明参数提取规则
   - 提供丰富的背景知识帮助理解内容

#### 关键代码解析

```python
# 知识库检索工具
def retrieve(dataset_id:str, query: str):
    '''
    用于检索知识库的工具，通过输入问题或者关键词来进行检索
    '''
    endpoint = f"/datasets/bb281f7e-50b6-4948-af99-85829116b23e/documents/{dataset_id}/segments?query={query}&status=completed"
    print(f"endpoint:{endpoint}")
    # 创建客户端实例
    dify = DifyDatasetsAPIClient()
    return dify.api_request("GET", endpoint)

# 智能体初始化
root_agent = Agent(
    name="second_paragragh_write_agent",
    model=model,
    description="第二章文档编辑专家",
    instruction=write_system_prompt,
    tools=[retrieve]
)
```

### text_agent模块

#### 核心组件

1. **多类型Agent组合** (`agent.py`)
   - `SequentialAgent`: 顺序执行多个子Agent
   - `LlmAgent`: 基于大语言模型的智能体
   - `LoopAgent`: 支持循环执行的智能体
   - `BaseAgent`: 自定义行为的基础智能体

2. **用户确认机制**
   - `request_user_confirmation_async`: 异步请求用户确认
   - `UserConfirmationChecker`: 检查用户确认状态

3. **状态管理**
   - 使用会话状态跟踪流程进度
   - 支持用户反馈和迭代优化

#### 关键代码解析

```python
# 用户确认工具
def request_user_confirmation_async(content: str, tool_context: ToolContext) -> dict:
    """异步请求用户确认的长时间运行工具"""
    # 生成唯一的确认ID
    confirmation_id = f"confirmation_{uuid.uuid4().hex[:8]}"
    
    # 存储待确认内容
    pending_confirmations[confirmation_id] = {
        "content": content,
        "status": "pending",
        "response": None,
        "agent_name": tool_context.agent_name
    }
    
    # 保存到会话状态
    tool_context.state["pending_confirmation"] = content
    tool_context.state["confirmation_id"] = confirmation_id
    tool_context.state["confirmation_requested"] = True
    
    # 标记为长时间运行工具
    tool_context.actions.long_running_tool_ids = [confirmation_id]
    
    return {
        "ticketId": confirmation_id,
        "message": f"内容已提交确认 (ID: {confirmation_id})。请在 Web UI 中回复'确认'或提供修改建议。",
        "status": "pending"
    }

# 循环智能体
outline_loop = LoopAgent(
    name="OutlineLoop",
    sub_agents=[
        outline_agent,
        UserConfirmationChecker(name="OutlineChecker", max_wait_iterations=100)
    ],
    max_iterations=10,
    description="重复执行大纲创建直到用户满意"
)
```

## API接口设计

### Dify数据集API客户端

#### 初始化
```python
class DifyDatasetsAPIClient:
    def __init__(self):
        load_dotenv()
        self.base_url ="http://172.16.56.101:8087/v1"
        self.api_key ="dataset-GcJSFfELpp8oZXcIskZ0bLsJ"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
```

#### 核心方法
```python
def api_request(self, method: str, endpoint: str, data: dict = None) -> dict:
    """发起带有 API KEY 的 JSON 请求"""
    # 支持GET、POST、PUT、DELETE方法
    # 自动处理响应和错误
    
def upload_file_request(self, endpoint: str, data: dict = None, files: dict = None) -> dict:
    """专用于文件上传场景的请求方法（multipart/form-data）"""
```

## 部署配置

### 环境变量配置

每个模块都需要配置相应的环境变量：

```bash
# .env文件示例
HOSTED_VLLM_API_BASE="http://172.16.56.101:8099/v1"
HOSTED_VLLM_API_KEY="64a6c2dc-56bc-4a93-b9d1-5da69e3a6abe"
HOSTED_VLLM_MODEL_ID=deepseek/deepseek-v3-0324
```

### 模型配置

系统默认使用DeepSeek v3模型，可根据需要切换：

```python
# 模型配置示例
model = LiteLlm(  
    model="hosted_vllm/deepseek/deepseek-v3-0324",  
    api_base=os.environ["HOSTED_VLLM_API_BASE"],  
    api_key=os.environ["HOSTED_VLLM_API_KEY"]
)
```

## 开发指南

### 新增功能模块

1. **创建新模块目录**
   ```bash
   mkdir new_module
   cd new_module
   touch __init__.py agent.py agent_prompt.yaml .env
   ```

2. **定义Agent逻辑** (`agent.py`)
   ```python
   from google.adk.agents import Agent
   from google.adk.models.lite_llm import LiteLlm
   
   model = LiteLlm(
       model="hosted_vllm/deepseek/deepseek-v3-0324",
       api_base=os.environ["HOSTED_VLLM_API_BASE"],
       api_key=os.environ["HOSTED_VLLM_API_KEY"]
   )
   
   root_agent = Agent(
       name="new_module_agent",
       model=model,
       description="新模块功能描述",
       instruction=system_prompt,
       tools=[]
   )
   ```

3. **编写Prompt** (`agent_prompt.yaml`)
   ```yaml
   system_prompt: |-
       你的角色定义和任务说明
       
       ## 工作流程
       1. 第一步：...
       2. 第二步：...
   ```

### 工具集成

1. **定义工具函数**
   ```python
   def custom_tool(param1: str, param2: int) -> str:
       '''
       工具功能说明
       '''
       # 实现逻辑
       return result
   ```

2. **注册工具到Agent**
   ```python
   root_agent = Agent(
       # ... 其他参数
       tools=[custom_tool]
   )
   ```

### 测试策略

1. **单元测试**
   - 对每个工具函数进行独立测试
   - 验证输入输出的正确性
   - 测试异常处理机制

2. **集成测试**
   - 测试模块间的协作
   - 验证端到端流程
   - 检查状态管理和会话跟踪

3. **性能测试**
   - 测量响应时间
   - 评估资源消耗
   - 测试并发处理能力

## 故障排除

### 常见问题

1. **API调用失败**
   - 检查网络连接
   - 验证API密钥和地址
   - 查看服务端日志

2. **模型响应异常**
   - 检查Prompt设计
   - 调整温度和最大token参数
   - 验证输入数据格式

3. **用户确认超时**
   - 检查Web UI连接
   - 增加等待时间限制
   - 优化用户交互流程

### 日志分析

系统会在关键步骤输出日志信息：

```python
print(f"[{agent_name}] 用户确认满意，退出循环")
print(f"response:{response.json()}")
print(f"endpoint:{endpoint}")
```

通过分析这些日志可以定位问题和优化性能。

## 性能优化建议

1. **Prompt优化**
   - 精简冗余描述
   - 明确输出格式
   - 添加示例引导

2. **缓存机制**
   - 对知识库检索结果进行缓存
   - 避免重复的计算操作

3. **并发处理**
   - 合理设置异步任务
   - 控制并发数量避免资源竞争

4. **资源管理**
   - 及时释放文件句柄
   - 优化内存使用
   - 合理设置超时时间
