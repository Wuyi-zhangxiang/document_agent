import os      
from dotenv import load_dotenv      
from typing import AsyncGenerator, Optional      
import asyncio      
import uuid      
      
load_dotenv(dotenv_path="multi_tool_agent/.env")      
      
required_env_vars = ["HOSTED_VLLM_API_BASE", "HOSTED_VLLM_API_KEY"]      
for var in required_env_vars:      
    if not os.getenv(var):      
        raise ValueError(f"环境变量 {var} 未设置，请检查 .env 文件")      
      
from google.adk.agents import SequentialAgent, LlmAgent, LoopAgent, BaseAgent      
from google.adk.models.lite_llm import LiteLlm      
from google.adk.tools.tool_context import ToolContext      
from google.adk.events import Event, EventActions      
from google.adk.agents.invocation_context import InvocationContext      
from google.adk.tools.long_running_tool import LongRunningFunctionTool  
      
model = LiteLlm(      
    model="hosted_vllm/deepseek/deepseek-v3-0324",      
    api_base=os.environ["HOSTED_VLLM_API_BASE"],      
    api_key=os.environ["HOSTED_VLLM_API_KEY"],      
)      
      
# 全局存储等待确认的请求      
pending_confirmations = {}      
      
def request_user_confirmation_async(content: str, tool_context: ToolContext) -> dict:      
    """异步请求用户确认的长时间运行工具"""      
          
    # 生成唯一的确认ID      
    confirmation_id = f"confirmation_{uuid.uuid4().hex[:8]}"      
          
    # 存储待确认内容      
    pending_confirmations[confirmation_id] = {      
        "content": content,      
        "status": "pending",      
        "response": None,      
        "agent_name": tool_context.agent_name      
    }      
          
    # 保存到会话状态      
    tool_context.state["pending_confirmation"] = content      
    tool_context.state["confirmation_id"] = confirmation_id      
    tool_context.state["confirmation_requested"] = True      
          
    # 标记为长时间运行工具      
    tool_context.actions.long_running_tool_ids = [confirmation_id]      
          
    return {      
        "ticketId": confirmation_id,      
        "message": f"内容已提交确认 (ID: {confirmation_id})。请在 Web UI 中回复'确认'或提供修改建议。",      
        "status": "pending"      
    }      
      
def check_confirmation_status(confirmation_id: str, tool_context: ToolContext) -> dict:      
    """检查确认状态的工具"""      
          
    if confirmation_id not in pending_confirmations:      
        return {"error": "确认ID不存在"}      
          
    confirmation = pending_confirmations[confirmation_id]      
          
    # 检查用户是否已响应      
    events = tool_context._invocation_context.session.events      
    if events:      
        # 从后往前查找最新的用户消息      
        for event in reversed(events):      
            if (event.author == 'user' and       
                event.content and       
                event.content.parts and      
                hasattr(event, 'timestamp')):      
                      
                for part in event.content.parts:      
                    if part.text:      
                        user_message = part.text.lower()      
                              
                        if '确认' in user_message or 'confirm' in user_message or '满意' in user_message:      
                            # 用户确认      
                            confirmation["status"] = "approved"      
                            confirmation["response"] = part.text      
                            tool_context.state["user_confirmed"] = True      
                            tool_context.state["confirmation_requested"] = False      
                                  
                            return {      
                                "status": "approved",      
                                "response": part.text,      
                                "message": "用户已确认满意"      
                            }     
                        else:      
                            # 用户要求修改      
                            confirmation["status"] = "rejected"      
                            confirmation["response"] = part.text      
                            tool_context.state["user_confirmed"] = False      
                            tool_context.state["user_feedback"] = part.text      
                            tool_context.state["confirmation_requested"] = False      
                                  
                            return {      
                                "status": "rejected",       
                                "response": part.text,      
                                "message": "用户要求修改"      
                            }      
                break      
          
    # 仍在等待用户响应      
    return {      
        "status": "pending",      
        "message": "等待用户确认中..."      
    }      
      
# 创建长时间运行的确认工具 - 修正参数      
confirmation_tool = LongRunningFunctionTool(request_user_confirmation_async)  
        
# 用户确认检查智能体 - 改进版      
class UserConfirmationChecker(BaseAgent):      
    """检查用户确认状态并决定是否终止循环"""      
    max_wait_iterations: int = 50
          
    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[Event, None]:      
        confirmation_id = ctx.session.state.get("confirmation_id")      
        confirmation_requested = ctx.session.state.get("confirmation_requested", False)      
              
        if not confirmation_requested or not confirmation_id:      
            # 没有待确认内容，正常退出      
            yield Event(author=self.name, actions=EventActions(escalate=True))      
            return     
              
        # 等待用户确认，最多等待指定次数      
        wait_count = 0      
        while wait_count < self.max_wait_iterations:      
            # 检查确认状态      
            status_result = check_confirmation_status(confirmation_id,       
                                                    ToolContext(ctx, self.name))      
                  
            if status_result["status"] == "approved":      
                print(f"[{self.name}] 用户确认满意，退出循环")      
                yield Event(author=self.name, actions=EventActions(escalate=True))      
                return      
            elif status_result["status"] == "rejected":      
                print(f"[{self.name}] 用户要求修改，继续循环")      
                yield Event(author=self.name, actions=EventActions(escalate=False))      
                return      
            else:      
                # 仍在等待，短暂休眠后继续检查      
                print(f"[{self.name}] 等待用户确认中... ({wait_count + 1}/{self.max_wait_iterations})")      
                await asyncio.sleep(2)  # 等待2秒      
                wait_count += 1      
              
        # 超时，强制退出      
        print(f"[{self.name}] 等待超时，强制退出循环")      
        yield Event(author=self.name, actions=EventActions(escalate=True))      
      
# 大纲智能体 - 使用长时间运行工具      
outline_agent = LlmAgent(      
    name="OutlineAgent",      
    model=model,      
    instruction="""你是文档大纲规划专家。根据用户需求创建四个章节的文档大纲。      
    如果状态中有用户反馈(user_feedback)，请根据反馈修改大纲。      
          
    请为每个章节提供：      
    1. 章节标题      
    2. 主要内容要点        
    3. 预期字数      
          
    将大纲保存到状态中，格式为：      
    - chapter1_title, chapter1_outline      
    - chapter2_title, chapter2_outline        
    - chapter3_title, chapter3_outline      
    - chapter4_title, chapter4_outline      
          
    完成后必须调用 request_user_confirmation_async 工具请求用户确认大纲。""",      
    tools=[confirmation_tool],      
    output_key="document_outline",      
    description="负责创建和确认文档大纲"      
)      
      
# 其他章节智能体类似修改...      
chapter1_agent = LlmAgent(      
    name="Chapter1Agent",       
    model=model,      
    instruction="""你是第一章节的专业写手。      
    根据大纲中的 chapter1_title 和 chapter1_outline 编写详细内容。      
    如果状态中有用户反馈(user_feedback)，请根据反馈修改内容。      
    确保内容结构清晰、逻辑严密。      
    完成后必须调用 request_user_confirmation_async 工具请求用户确认。""",      
    tools=[confirmation_tool],      
    output_key="chapter1_content",      
    description="编写文档第一章节"      
)      
      
# 创建循环智能体 - 使用改进的确认检查器      
outline_loop = LoopAgent(      
    name="OutlineLoop",      
    sub_agents=[      
        outline_agent,      
        UserConfirmationChecker(name="OutlineChecker", max_wait_iterations=100)      
    ],      
    max_iterations=10,      
    description="重复执行大纲创建直到用户满意"      
)      
      
chapter1_loop = LoopAgent(      
    name="Chapter1Loop",       
    sub_agents=[      
        chapter1_agent,      
        UserConfirmationChecker(name="Chapter1Checker", max_wait_iterations=100)      
    ],      
    max_iterations=10,      
    description="重复执行第一章编写直到用户满意"      
)      
      
# 主要工作流程保持不变      
root_agent = SequentialAgent(      
    name="DocumentWritingPipeline",      
    sub_agents=[      
        outline_loop,      
        chapter1_loop,      
        # 其他循环...      
    ],      
    description="文档编写多智能体流水线：每个节点都支持重复执行直到用户满意"      
)      
      
if __name__ == "__main__":      
    print("请使用 'adk web' 命令启动 Web UI 来运行此智能体")      
    print("启动命令: adk web")
