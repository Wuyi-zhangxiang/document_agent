import asyncio  
import os  
from dotenv import load_dotenv  
from google.adk.planners import PlanReActPlanner
  
load_dotenv(dotenv_path="multi_tool_agent/.env")  
  
required_env_vars = ["HOSTED_VLLM_API_BASE", "HOSTED_VLLM_API_KEY"]  
for var in required_env_vars:  
    if not os.getenv(var):  
        raise ValueError(f"环境变量 {var} 未设置，请检查 .env 文件")  
  
from google.adk.agents import SequentialAgent, Agent  
from google.adk.models.lite_llm import LiteLlm  
  
# 常量定义  
APP_NAME = "proposal_writing_app"  
USER_ID = "dev_user_01"  
SESSION_ID_BASE = "proposal_writing_session"  
  
model = LiteLlm(  
    model="hosted_vllm/deepseek/deepseek-v3-0324",  
    api_base=os.environ["HOSTED_VLLM_API_BASE"],  
    api_key=os.environ["HOSTED_VLLM_API_KEY"],  
)  
  
# 读取系统提示  
system_prompt = " "  
with open(r"E:\\adk\\multi_tool_agent\\agent_prompt.yaml", 'r', encoding="utf-8") as f:  
    system_prompt = f.read()  
  
# 工具函数  
def write_file(content: str, filename: str) -> str:  
    with open(filename, "w", encoding="utf-8") as file:  
        file.write(content)  
    return f"成功将内容写入到 {filename}"  
  
def read_file(filename: str) -> str:  
    """读取文件内容并返回文本"""  
    with open(filename, "r", encoding="utf-8") as file:  
        content = file.read()  
    return content
  

  
# 创建顺序工作流  
root_agent = Agent(  
    name="纪要分析智能体",  
    model=model,
    planner=PlanReActPlanner(),
    description="按顺序执行文档读取和写入的完整工作流",  
    instruction=system_prompt,
    tools=[write_file, read_file] 
)