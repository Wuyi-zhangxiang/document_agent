import json
import os

import requests
from dotenv import load_dotenv


class DifyDatasetsAPIClient:
    def __init__(self):
        load_dotenv()
        self.base_url ="http://172.16.56.101:8087/v1"
        self.api_key ="dataset-GcJSFfELpp8oZXcIskZ0bLsJ"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    def api_request(self, method: str, endpoint: str, data: dict = None) -> dict:
        """发起带有 API KEY 的 JSON 请求"""
        url = self.base_url + endpoint

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }
        # 根据方法选择合适的 requests 函数
        if method.upper() == "GET":
            response = requests.get(url, headers=headers, params=data)
        elif method.upper() == "POST":
            response = requests.post(url, headers=headers, json=data)
        elif method.upper() == "PUT":
            response = requests.put(url, headers=headers, json=data)
        elif method.upper() == "DELETE":
            response = requests.delete(url, headers=headers)
        else:
            raise ValueError(f"不支持的 HTTP 方法: {method}")

        response.raise_for_status()  # 检查响应状态码
        print(f"response:{response.json()}")
        try:
            return response.json()
        except json.JSONDecodeError:
            return {"text": response.text}

    def upload_file_request(
        self, endpoint: str, data: dict = None, files: dict = None
    ) -> dict:
        """
        专用于文件上传场景的请求方法（multipart/form-data）
        """
        url = self.base_url + endpoint

        headers = {
            "Authorization": f"Bearer {self.api_key}",
        }
        response = requests.post(url, headers=headers, data=data, files=files)
        # response.raise_for_status()
        print(response.text)

        try:
            return response.json()
        except json.JSONDecodeError:
            return {"text": response.text}
