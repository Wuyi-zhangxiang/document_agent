from .client import DifyDatasetsAPIClient
from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm 
from google.adk.sessions import InMemorySessionService
from google.adk.runners import Runner
from google.genai import types 
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset,StdioServerParameters

#加载系统提示词
paln_system_prompt=" "

with open("E:/adk-master/agent/plan_agent/plan_agent_prompt.yaml",'r',encoding="utf-8") as f:
    paln_system_prompt=f.read()

write_system_prompt=" "

with open("E:/adk-master/agent/plan_agent/write_agent_prompt.yaml",'r',encoding="utf-8") as f:
    write_system_prompt=f.read()

#注意model命名规则，需要在模型名称前写对应的提供商，例如openai、huggingface等
model=LiteLlm(
    model="hosted_vllm/deepseek-v3-0324",
    api_base="http://172.16.56.101:8002/v1",
    api_key="64a6c2dc-56bc-4a93-b9d1-5da69e3a6abe" 
    
    # model="openai/stepfun-ai/step3",
    # api_base="https://api.siliconflow.cn/v1",
    # api_key="sk-jsdudnymyyrtjcxfvhvudcuoqmxeyhlnvvoacvdduwyfqlvy"
    
    # model="openai/llama3.2:1b",
    # api_base="http://172.16.52.100:10000/v1",
    # api_key="empty"
)

#函数、mcp工具------------------------------------------------

#写入函数工具
def write_file(content: str, filename: str,) -> str:
    '''
    将获取到的内容写入到指定文件中
    '''
    with open(filename,"w",encoding="utf-8") as file:
        file.write(content)
    return f"成功将内容写入到 {filename}"
#读取函数工具
def read_file(filename: str) -> str:
    '''
    读取文件内容的工具
    '''
    with open(filename, "r", encoding="utf-8") as file:
        content = file.read()
    return content
#检索函数工具
def retrieve(document_id:str,dataset_id:str,query: str):
    '''
    用于检索知识库的工具，通过输入问题或者关键词来进行检索
    document_id:1416230e-5b96-4d29-b5a4-53cd49abfefd, dataset_id:975b5060-c256-4415-9014-021c1cfa1490
    '''
    endpoint = f"/datasets/{document_id}/documents/{dataset_id}/segments?query={query}&status=completed"
    print(f"endpoint:{endpoint}")
    # 创建客户端实例
    dify = DifyDatasetsAPIClient()
    return dify.api_request("GET", endpoint)


#markdown工具----StdioConnectionParams----------------------------------------------
# markdown_tool=MCPToolset(
#             connection_params=StdioServerParameters(
#                 command='node',
#                 args=[
#                      "C:\\Users\\WA\\Documents\\MCP\\markdownify-mcp\\dist\\index.js"
#                 ],
#                 env={"UV_PATH":"C:/Users/WA/uv"}
#             )        
# )    
 
 
#创建编写文档智能体
write_agent=Agent(
    name="write_agent",
    model=model,
    description="通过检索内容进行文档编辑",
    instruction=write_system_prompt,
    tools=[write_file,retrieve]
)


# 创建根Agent智能体
root_agent = Agent(
    name="plan_agent",
    model=model,
    description="一个规划智能体，用于创建和管理解决复杂任务的计划。",
    instruction=paln_system_prompt,
    tools=[read_file],
    sub_agents=[write_agent]
)




# session_service = InMemorySessionService()
 
# APP_NAME = "plan_app"
# USER_ID = "user01"
# SESSION_ID = "session01"


# #使用同步方法
# session =  session_service.create_session_sync(
#     app_name=APP_NAME,
#     user_id=USER_ID,
#     session_id=SESSION_ID,
# )
 
# print(f"创建初始Session: {session.app_name} - {session.user_id} - {session.id}")
 
# 创建智能体执行器
# runner = Runner(
#     agent=root_agent,
#     app_name="plan_app",
#     session_service=session_service
# )

# # 执行对话 由于LLM调用和工具执行需要时间，所以ADK中的run是异步执行的。
# async def call_agent_async(query: str, runner, user_id, session_id):

#   content = types.Content(role='user', parts=[types.Part(text=query)])
 
#   final_response_text = "Agent未生成最终响应。" # Default

#   print(f"content:{content}")
#   async for event in runner.run_async(user_id=user_id, session_id=session_id, new_message=content):
 
#       if event.is_final_response():
#           if event.content and event.content.parts:
#              # 假设响应文本位于首部分
#              final_response_text = event.content.parts[0].text
#           elif event.actions and event.actions.escalate: # Handle potential errors/escalations
#              final_response_text = f"Agent escalated: {event.error_message or 'No specific message.'}"
#           break # 找到最终响应后停止处理事件
 
#   print(f"<<< Agent Response: {final_response_text}")
