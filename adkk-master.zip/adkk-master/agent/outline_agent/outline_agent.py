from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm 
from google.adk.sessions import InMemorySessionService
from google.adk.runners import Runner
from google.genai import types 
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset,StdioServerParameters
#加载系统提示词
system_prompt=" "

with open("E:/adk-master/agent/outline_agent/outline_agent_prompt.yaml",'r',encoding="utf-8") as f:
    system_prompt=f.read()

#注意model命名规则，需要在模型名称前写对应的提供商，例如openai、huggingface等
model=LiteLlm(
    model="hosted_vllm/deepseek-v3-0324",
    api_base="http://172.16.56.101:8002/v1",
    api_key="64a6c2dc-56bc-4a93-b9d1-5da69e3a6abe" 
)
#写文件的函数工具
def write_file(content: str, filename: str,) -> str:
    with open(filename,"w",encoding="utf-8") as file:
        file.write(content)
    return f"Successfully wrote content to {filename}"
#markdown工具--------------------------------------------------
# markdown_tool=MCPToolset(
#             connection_params=StdioServerParameters(
#                 command='node',
#                 args=[
#                      "C:\\Users\\WA\\Documents\\MCP\\markdownify-mcp\\dist\\index.js"
#                 ],
#                 env={"UV_PATH":"C:/Program Files/uv"}
#             )        
# )    
 
# 创建根Agent智能体
root_agent = Agent(
    name="outline_agent",
    model=model,
    description="An outline generation agent that automatically builds document frameworks based on user input material",
    instruction=system_prompt,
    tools=[write_file]
)

# session_service = InMemorySessionService()
 
# APP_NAME = "outline_app"
# USER_ID = "user01"
# SESSION_ID = "session01"


# #使用同步方法
# session =  session_service.create_session_sync(
#     app_name=APP_NAME,
#     user_id=USER_ID,
#     session_id=SESSION_ID,
# )
 
# print(f"创建初始Session: {session.app_name} - {session.user_id} - {session.id}")
 
# # 创建智能体执行器
# runner = Runner(
#     agent=root_agent,
#     app_name="outline_app",
#     session_service=session_service
# )
 
# # 执行对话 由于LLM调用和工具执行需要时间，所以ADK中的run是异步执行的。
# async def call_agent_async(query: str, runner, user_id, session_id):

#   content = types.Content(role='user', parts=[types.Part(text=query)])
 
#   final_response_text = "Agent未生成最终响应。" # Default

#   print(f"content:{content}")
#   async for event in runner.run_async(user_id=user_id, session_id=session_id, new_message=content):
 
#       if event.is_final_response():
#           if event.content and event.content.parts:
#              # 假设响应文本位于首部分
#              final_response_text = event.content.parts[0].text
#           elif event.actions and event.actions.escalate: # Handle potential errors/escalations
#              final_response_text = f"Agent escalated: {event.error_message or 'No specific message.'}"
#           break # 找到最终响应后停止处理事件
 
#   print(f"<<< Agent Response: {final_response_text}")