from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm 
from outline_agent import outline_agent
from plan_agent import plan_agent
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset,StdioServerParameters
#加载大纲生成智能体
outlineAgent=outline_agent.root_agent
#加载任务规划执行智能体
planAgent=plan_agent.root_agent

#加载系统提示词
system_prompt="You are the main coordinating intelligent body of the document automation system (Main Agent), responsible for the overall management of the entire document creation process, first of all, accept user input information and materials, call outline_agent to generate the outline, according to the content of the generated outline call plan_agent to complete the final document report, Requirements: Strictly in accordance with the workflow of each intelligent body to execution, must show the execution process and results to the user."

# with open("E:/code/adk/agent/main_agent/main_agent_prompt.yaml",'r',encoding="utf-8") as f:
#     system_prompt=f.read()

#注意model命名规则，需要在模型名称前写对应的提供商，例如openai、huggingface等

model=LiteLlm(
    model="hosted_vllm/deepseek-v3-0324",
    api_base="http://172.16.56.101:8002/v1",
    api_key="64a6c2dc-56bc-4a93-b9d1-5da69e3a6abe" 
)
 #写文件的函数工具
# def write_file(content: str, filename: str,) -> str:
#     with open(filename,"w",encoding="utf-8") as file:
#         file.write(content)
#     return f"Successfully wrote content to {filename}"  
# 读取文件内容工具
def read_file(filename: str) -> str:
    with open(filename, "r", encoding="utf-8") as file:
        content = file.read()
    return content
#markdown工具----StdioConnectionParams----------------------------------------------
# markdown_tool=MCPToolset(
#             connection_params=StdioServerParameters(
#                 command='node',
#                 args=[
#                      "C:\\Users\\WA\\Documents\\MCP\\markdownify-mcp\\dist\\index.js"
#                 ],
#                 env={"UV_PATH":"C:/Users/WA/uv"}
#             )        
# )  
# 创建根Agent智能体
root_agent = Agent(
    name="main_agent",
    model=model,
    description="A master document authoring authoring agent, responsible for coordinating and managing the entire document creation process, including outline generation, task planning and execution.",
    instruction=system_prompt,
    tools=[read_file],
    sub_agents=[outlineAgent,planAgent]
)

