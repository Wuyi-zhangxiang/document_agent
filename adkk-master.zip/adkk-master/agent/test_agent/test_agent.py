import asyncio
from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm # For multi-model support
from google.adk.sessions import InMemorySessionService
from google.adk.runners import Runner
from google.genai import types # For creating message Content/Parts

system_prompt=" "
with open(r"E:\\adk-master\\agent\\test_agent\\agent_prompt.yaml",'r',encoding="utf-8") as f:
    system_prompt=f.read()

#写入函数工具
def write_file(content: str, filename: str,) -> str:
    '''
    将获取到的内容写入到指定文件中
    '''
    with open(filename,"w",encoding="utf-8") as file:
        file.write(content)
    return f"成功将内容写入到 {filename}"


#读取函数工具
def read_file(filename: str) -> str:
    '''
    读取文件内容的工具
    '''
    with open(filename, "r", encoding="utf-8") as file:
        content = file.read()
    return content
    
model=LiteLlm(
    model="hosted_vllm/deepseek/deepseek-v3-0324",
    api_base="http://172.16.56.101:8099/v1",
    api_key="64a6c2dc-56bc-4a93-b9d1-5da69e3a6abe"
    
)

# 创建Agent智能体
root_agent = Agent(
    name="纪要分析助手",
    model=model,
    description="纪要文档分析专家",
    instruction=system_prompt,
    tools=[write_file,read_file]
)
