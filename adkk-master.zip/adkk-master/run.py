#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
ADK多智能体文档处理系统启动脚本
"""

import os
import sys
import subprocess
from pathlib import Path

def check_environment():
    """检查环境配置"""
    print("正在检查环境配置...")
    
    # 检查必需的环境变量
    required_vars = ["HOSTED_VLLM_API_BASE", "HOSTED_VLLM_API_KEY"]
    missing_vars = []
    
    for var in required_vars:
        if not os.getenv(var):
            missing_vars.append(var)
    
    if missing_vars:
        print(f"警告: 以下环境变量未设置: {', '.join(missing_vars)}")
        print("请确保在运行前配置好.env文件")
        return False
    
    print("环境配置检查通过")
    return True

def run_module(module_name):
    """运行指定模块"""
    print(f"正在启动 {module_name} 模块...")
    
    module_path = Path(module_name)
    if not module_path.exists():
        print(f"错误: 模块 {module_name} 不存在")
        return False
    
    agent_file = module_path / "agent.py"
    if not agent_file.exists():
        print(f"错误: 未找到 {module_name}/agent.py 文件")
        return False
    
    try:
        # 启动ADK Web界面
        subprocess.run(["adk", "web"], cwd=module_path, check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"启动失败: {e}")
        return False
    except FileNotFoundError:
        print("错误: 未找到 adk 命令，请确保已安装 ADK 框架")
        return False

def main():
    """主函数"""
    print("ADK多智能体文档处理系统启动器")
    print("=" * 40)
    
    # 检查环境
    if not check_environment():
        print("环境检查失败，退出程序")
        sys.exit(1)
    
    # 获取用户选择
    print("\n可用模块:")
    print("1. data_agent - 会议纪要信息提取模块")
    print("2. second_paragragh_write - 文档第二章节生成模块")
    print("3. text_agent - 文档编写流程控制模块")
    print("4. 退出")
    
    while True:
        try:
            choice = input("\n请选择要启动的模块 (1-4): ").strip()
            
            if choice == "1":
                run_module("data_agent")
                break
            elif choice == "2":
                run_module("second_paragragh_write")
                break
            elif choice == "3":
                run_module("text_agent")
                break
            elif choice == "4":
                print("退出程序")
                break
            else:
                print("无效选择，请输入 1-4 之间的数字")
                
        except KeyboardInterrupt:
            print("\n\n程序被用户中断")
            break
        except Exception as e:
            print(f"发生错误: {e}")
            break

if __name__ == "__main__":
    main()
