import pprint
import urllib.parse
import json5
from qwen_agent.agents import Assistant
from qwen_agent.tools.base import BaseTool, register_tool
from qwen_agent.utils.output_beautify import typewriter_print

# 步骤 1（可选）：添加一个名为 `docx_generator` 的自定义工具。
@register_tool('docx_generator')
class MyImageGen(BaseTool):
    # `description` 用于告诉智能体该工具的功能。
    description = 'AI 文档服务，输入文本描述，返回基于文本信息制作的文档 URL。'
    # `parameters` 告诉智能体该工具有哪些输入参数。
    parameters = [{
        'name': 'prompt',
        'type': 'string',
        'description': '期望生成文档内容的详细描述',
        'required': True
    }]

    def call(self, params: str, **kwargs) -> str:
        # `params` 是由 LLM 智能体生成的参数。
        prompt = json5.loads(params)['prompt']
        prompt = urllib.parse.quote(prompt)
        return json5.dumps(
            {'word_url': f'https://image.pollinations.ai/prompt/{prompt}'},
            ensure_ascii=False)


    llm_cfg = {
    # 使用 DashScope 提供的模型服务：
    'model': 'deepseek-v3-0324',
    'model_server': 'http://172.16.56.101:8099/v1', 
    'api_key': '64a6c2dc-56bc-4a93-b9d1-5da69e3a6abe',
    # 'api_key': 'YOUR_DASHSCOPE_API_KEY',
    # 如果这里没有设置 'api_key'，它将读取 `DASHSCOPE_API_KEY` 环境变量。

    # 使用与 OpenAI API 兼容的模型服务，例如 vLLM 或 Ollama：
    # 'model': 'Qwen2.5-7B-Instruct',
    # 'model_server': 'http://localhost:8000/v1',  # base_url，也称为 api_base
    # 'api_key': 'EMPTY',

    # （可选） LLM 的超参数：
    'generate_cfg': {
        'top_p': 0.7
    }
}
    
    system_instruction = '''在收到用户的请求后，你应该：
                        - 首先阅读用户需求，回复用户完成情况并且返回文档'
                        你总是用中文回复用户。'''
    tools = ['docx_generator', 'code_interpreter']  # `code_interpreter` 是框架自带的工具，用于执行代码。
    files = ['./examples/resource/doc.pdf']  # 给智能体一个 PDF 文件阅读。
    bot = Assistant(llm=llm_cfg,
                system_message=system_instruction,
                function_list=tools,
                files=files)
    
    bot = Assistant(
    llm=llm_cfg,
    function_list=tools,
    name=' 文档生成智能体',
    description="你是一个能阅读文档内容，和生成文档的ai")

    
    # 步骤 4：作为聊天机器人运行智能体。
messages = []  # 这里储存聊天历史。
while True:
    # 例如，输入请求 "绘制一只狗并将其旋转 90 度"。
    query = input('\n用户请求: ')
    # 将用户请求添加到聊天历史。
    messages.append({'role': 'user', 'content': query})
    response = []
    response_plain_text = ''
    print('机器人回应:')
    for response in bot.run(messages=messages):
        # 流式输出。
        response_plain_text = typewriter_print(response, response_plain_text)
    # 将机器人的回应添加到聊天历史。
    messages.extend(response)