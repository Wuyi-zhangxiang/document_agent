# Copyright 2023 The Qwen team, Alibaba Group. All rights reserved.
# Licensed under the Apache License, Version 2.0 (the "License");

import os
from typing import Dict, Optional
from docx import Document
import markdown
from markdown.extensions.tables import TableExtension

from qwen_agent.tools.base import BaseTool, register_tool

@register_tool('format_converter')
class FormatConverter(BaseTool):
    description = 'Handle conversion between Word and Markdown formats'
    parameters = [{
        'name': 'file_path',
        'type': 'string',
        'description': 'Path to the input file',
        'required': True
    }, {
        'name': 'output_format',
        'type': 'string',
        'description': 'Target format: "markdown" or "docx"',
        'required': True
    }]

    def call(self, params: Dict, **kwargs) -> Dict:
        file_path = params['file_path']
        output_format = params['output_format'].lower()

        if output_format == 'markdown':
            return self._word_to_markdown(file_path)
        elif output_format == 'docx':
            return self._markdown_to_word(file_path)
        else:
            raise ValueError(f'Unsupported format: {output_format}')

    def _word_to_markdown(self, file_path: str) -> Dict:
        """Convert Word document to Markdown format"""
        doc = Document(file_path)
        md_content = []
        
        for element in doc.element.body:
            if element.tag.endswith('p'):  # Paragraph
                para = doc.paragraphs[doc.paragraphs.index(element)]
                md_content.append(para.text)
            elif element.tag.endswith('tbl'):  # Table
                table = doc.tables[doc.tables.index(element)]
                md_content.append(self._table_to_markdown(table))
            
        return {
            'content': '\n\n'.join(md_content),
            'format': 'markdown'
        }

    def _markdown_to_word(self, file_path: str) -> Dict:
        """Convert Markdown to Word document"""
        with open(file_path, 'r', encoding='utf-8') as f:
            md_content = f.read()
        
        html = markdown.markdown(md_content, extensions=[TableExtension()])
        doc = Document()
        
        # Basic conversion - will enhance in later versions
        doc.add_paragraph(html)
        
        output_path = os.path.splitext(file_path)[0] + '_converted.docx'
        doc.save(output_path)
        
        return {
            'output_path': output_path,
            'format': 'docx'
        }

    def _table_to_markdown(self, table) -> str:
        """Helper to convert Word tables to Markdown"""
        rows = []
        for i, row in enumerate(table.rows):
            cells = []
            for cell in row.cells:
                cells.append(cell.text)
            rows.append('| ' + ' | '.join(cells) + ' |')
            
            if i == 0:  # Add header separator
                rows.append('|' + '|'.join(['---'] * len(row.cells)) + '|')
                
        return '\n'.join(rows)
