# Copyright 2023 The Qwen team, Alibaba Group. All rights reserved.
# Licensed under the Apache License, Version 2.0 (the "License");

import re
from typing import Dict, List, Optional
from pathlib import Path

from qwen_agent.tools.base import BaseTool, register_tool

@register_tool('chapter_editor')
class ChapterEditor(BaseTool):
    description = 'Handle document chapter splitting, editing and merging'
    parameters = [{
        'name': 'action',
        'type': 'string',
        'description': 'Action to perform: "split", "edit" or "merge"',
        'required': True
    }, {
        'name': 'file_path',
        'type': 'string',
        'description': 'Path to the input file',
        'required': True
    }]

    def call(self, params: Dict, **kwargs) -> Dict:
        action = params['action'].lower()
        file_path = params['file_path']

        if action == 'split':
            return self._split_chapters(file_path)
        elif action == 'edit':
            return self._edit_chapter(params)
        elif action == 'merge':
            return self._merge_chapters(file_path)
        else:
            raise ValueError(f'Unsupported action: {action}')

    def _split_chapters(self, file_path: str) -> Dict:
        """Split document into chapters based on headings"""
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()

        chapters = []
        current_chapter = []
        current_title = 'Introduction'
        lines = content.split('\n')

        for line in lines:
            if self._is_heading(line):
                if current_chapter:
                    chapters.append({
                        'title': current_title,
                        'content': '\n'.join(current_chapter)
                    })
                    current_chapter = []
                current_title = line.lstrip('#').strip()
            current_chapter.append(line)

        if current_chapter:
            chapters.append({
                'title': current_title,
                'content': '\n'.join(current_chapter)
            })

        # Save chapters to individual files
        output_dir = Path(file_path).parent / 'chapters'
        output_dir.mkdir(exist_ok=True)

        chapter_files = []
        for i, chapter in enumerate(chapters):
            chapter_path = output_dir / f'chapter_{i+1}.md'
            with open(chapter_path, 'w', encoding='utf-8') as f:
                f.write(chapter['content'])
            chapter_files.append({
                'title': chapter['title'],
                'path': str(chapter_path)
            })

        return {
            'chapters': chapter_files,
            'original_path': file_path
        }

    def _edit_chapter(self, params: Dict) -> Dict:
        """Edit a specific chapter based on modification instructions"""
        chapter_path = params['file_path']
        instructions = params.get('instructions', '')
        
        with open(chapter_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Analyze modification instructions
        analysis = self.llm.chat([{
            'role': 'system',
            'content': 'Analyze document modification instructions and generate specific edits'
        }, {
            'role': 'user',
            'content': f'Original content:\n{content}\n\nInstructions:\n{instructions}'
        }])
        
        # Apply modifications
        modified_content = self._apply_modifications(content, analysis)
        
        # Save modified content
        with open(chapter_path, 'w', encoding='utf-8') as f:
            f.write(modified_content)
            
        return {
            'status': 'modified',
            'original_path': chapter_path,
            'modifications': analysis
        }

    def _apply_modifications(self, content: str, analysis: str) -> str:
        """Apply the modifications based on LLM analysis"""
        # Simple implementation - will enhance later
        if 'replace' in analysis.lower():
            # Extract replacement info from analysis
            return content  # Placeholder
        return content

    def _merge_chapters(self, file_path: str) -> Dict:
        """Merge edited chapters back into a single document"""
        chapter_dir = Path(file_path).parent / 'chapters'
        if not chapter_dir.exists():
            return {'error': 'No chapters directory found'}
            
        merged_content = []
        chapter_files = sorted(chapter_dir.glob('chapter_*.md'))
        
        for chap_file in chapter_files:
            with open(chap_file, 'r', encoding='utf-8') as f:
                merged_content.append(f.read())
                
        output_path = Path(file_path).with_name('merged_' + Path(file_path).name)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(merged_content))
            
        return {
            'status': 'merged',
            'output_path': str(output_path)
        }

    def _is_heading(self, line: str) -> bool:
        """Check if a line is a Markdown heading"""
        return line.startswith('#') and len(line.strip()) > 1
