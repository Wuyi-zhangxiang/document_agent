from typing import Dict, List, Optional
from qwen_agent.agent import Agent
from qwen_agent.llm.schema import Message, ContentItem
from qwen_agent.tools.doc_parser import DocParser
from qwen_agent.log import logger
from pydantic import BaseModel, Field

class Section(BaseModel):
    name: str
    description: str = Field(default="")
    subsections: List['Section'] = Field(default_factory=list)

class OutlineTemplate(BaseModel):
    name: str
    description: str
    sections: List[Section]

class OutlineAgent(Agent):
    def __init__(self, llm=None, system_message=None, files=None):
        super().__init__(llm=llm, system_message=system_message, files=files)
        self.doc_parser = DocParser()
        self.templates = {
            'technical': OutlineTemplate(
                name='Technical Document',
                description='Template for technical documentation',
                sections=[
                    Section(name='Introduction', description='Overview of the document'),
                    Section(name='Architecture', description='System design and components'),
                    Section(name='Implementation', description='Technical details'),
                    Section(name='References', description='Related materials')
                ]
            ),
            'business': OutlineTemplate(
                name='Business Document',
                description='Template for business proposals and reports',
                sections=[
                    Section(name='Executive Summary', description='Brief overview'),
                    Section(name='Problem Statement', description='Business need or issue'),
                    Section(name='Solution', description='Proposed approach'),
                    Section(name='Financials', description='Costs and benefits')
                ]
            ),
            'academic': OutlineTemplate(
                name='Academic Paper',
                description='Template for research papers',
                sections=[
                    Section(name='Abstract', description='Summary of the paper'),
                    Section(name='Introduction', description='Background and motivation'),
                    Section(name='Methodology', description='Research approach'),
                    Section(name='Results', description='Findings and analysis'),
                    Section(name='Conclusion', description='Summary and implications')
                ]
            )
        }

    def _run(self, messages: List[Message], lang: str = 'en', **kwargs):
        # Parse input document if provided
        doc_content = self._parse_input_document(messages)
        
        # Determine document type and select template
        doc_type = self._determine_document_type(messages, doc_content)
        template = self.templates.get(doc_type, self.templates['technical'])
        
        # Generate outline with content suggestions
        outline = self._generate_outline(template, doc_content)
        
        # Format output
        return [self._format_output(outline)]

    def _parse_input_document(self, messages: List[Message]) -> Optional[Dict]:
        """从消息中提取并解析文档内容"""
        if not messages or not isinstance(messages, list):
            return None
            
        for msg in messages:
            if not hasattr(msg, 'content'):
                continue
                
            content = msg.content
            files = []
            
            # 处理content为None的情况
            if content is None:
                continue
                
            # 处理content为字符串的情况
            if isinstance(content, str):
                continue
                
            # 处理content为ContentItem列表的情况
            if isinstance(content, list):
                for item in content:
                    if item is None:
                        continue
                    if isinstance(item, dict):
                        try:
                            item = ContentItem(**item)
                        except Exception:
                            continue
                    if hasattr(item, 'file') and item.file:
                        files.append(item.file)
            
            # 解析找到的文件
            for file in files:
                try:
                    parsed = self.doc_parser.call({'url': file})
                    return {
                        'title': parsed.get('title', ''),
                        'content': [chunk['content'] for chunk in parsed.get('raw', [])],
                        'metadata': parsed
                    }
                except Exception as e:
                    logger.warning(f'解析文档失败 {file}: {str(e)}')
        return None

    def _determine_document_type(self, 
                              messages: List[Message],
                              doc_content: Optional[Dict]) -> str:
        """确定最适合的文档类型"""
        if not doc_content:
            # 如果没有文档内容，默认返回技术文档类型
            return 'technical'
            
        content = ' '.join(doc_content['content'])
        
        # 检查学术论文关键词
        academic_terms = ['abstract', 'introduction', 'methodology', 'references']
        if any(term in content.lower() for term in academic_terms):
            return 'academic'
            
        # 检查商业文档关键词
        business_terms = ['executive summary', 'financial', 'proposal', 'roi']
        if any(term in content.lower() for term in business_terms):
            return 'business'
            
        return 'technical'

    def _generate_outline(self, 
                        template: OutlineTemplate,
                        doc_content: Optional[Dict]) -> List[Section]:
        """生成带有内容建议的大纲"""
        if not doc_content:
            return template.sections
            
        # 使用文档内容增强章节
        enhanced_sections = []
        for section in template.sections:
            # 查找与该章节相关的内容
            relevant_content = []
            for chunk in doc_content['content']:
                if section.name.lower() in chunk.lower():
                    relevant_content.append(chunk)
                    
            # 创建增强后的章节
            enhanced = Section(
                name=section.name,
                description=section.description,
                subsections=section.subsections.copy()
            )
            
            if relevant_content:
                # 添加内容建议作为子章节
                for i, content in enumerate(relevant_content[:3]):  # 限制最多3条建议
                    enhanced.subsections.append(
                        Section(name=f'内容建议 {i+1}',
                              description=content[:200] + '...')  # 截断过长的内容
                    )
                    
            enhanced_sections.append(enhanced)
            
        return enhanced_sections

    def _format_output(self, outline: List[Section]) -> Message:
        """将大纲格式化为Markdown"""
        markdown = "# Document Outline\n\n"
        for section in outline:
            markdown += self._format_section(section, level=2)
        return Message('assistant', markdown)

    def _format_section(self, section: Section, level: int) -> str:
        """递归格式化章节及其子章节"""
        indent = '#' * level
        text = f"{indent} {section.name}\n"
        if section.description:
            text += f"{section.description}\n\n"
        for subsection in section.subsections:
            text += self._format_section(subsection, level + 1)
        return text

    def add_template(self, name: str, template: OutlineTemplate):
        """添加自定义大纲模板"""
        self.templates[name] = template
