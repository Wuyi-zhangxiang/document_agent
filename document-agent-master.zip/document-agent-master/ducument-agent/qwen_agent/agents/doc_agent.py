# Copyright 2023 The Qwen team, Alibaba Group. All rights reserved.
# Licensed under the Apache License, Version 2.0 (the "License");

import os
import tempfile
from typing import Dict, List, Optional

from qwen_agent.agents import Assistant
from qwen_agent.tools import format_converter, chapter_editor
from qwen_agent.tools.base import BaseTool, register_tool

@register_tool('doc_agent')
class DocAgent(Assistant):
    name = 'doc_agent'
    description = 'Document processing agent for Word to Markdown conversion with chapter editing'
    
    def __init__(self, llm=None, **kwargs):
        super().__init__(llm=llm, **kwargs)
        self.tools = {
            'format_converter': format_converter.FormatConverter(),
            'chapter_editor': chapter_editor.ChapterEditor()
        }
        self.work_dir = tempfile.mkdtemp(prefix='doc_agent_')

    def _run(self, messages: List[Dict], lang: str = 'en', **kwargs) -> Dict:
        """Main document processing workflow"""
        # Step 1: Get input file path
        input_file = self._get_input_file(messages)
        if not input_file:
            return {'error': 'No valid input file provided'}

        # Step 2: Convert Word to Markdown
        md_file = self._convert_to_markdown(input_file)
        if not md_file:
            return {'error': 'Failed to convert to Markdown'}

        # Step 3: Split into chapters
        chapters = self._split_chapters(md_file)
        if not chapters:
            return {'error': 'Failed to split chapters'}

        # Step 4: Process modifications (to be implemented)
        modified_chapters = self._process_modifications(chapters, messages)

        # Step 5: Merge chapters
        merged_file = self._merge_chapters(modified_chapters)

        # Step 6: Convert back to Word
        output_file = self._convert_to_word(merged_file)

        if not output_file:
            return {
                'status': 'failed',
                'error': 'Failed to generate output document',
                'temp_dir': self.work_dir
            }
            
        return [{
            'name': self.name,
            'content': {
                'status': 'completed',
                'input_file': input_file,
                'output_file': output_file,
                'modified_chapters': len(modified_chapters) if modified_chapters else 0,
                'temp_dir': self.work_dir,
                'message': '文档处理完成'
            }
        }]

    def _get_input_file(self, messages: List[Dict]) -> Optional[str]:
        """Extract input file path from messages"""
        for msg in reversed(messages):
            if msg.get('role') == 'user' and msg.get('file'):
                file_path = msg['file']
                if os.path.exists(file_path) and file_path.lower().endswith('.docx'):
                    return file_path
        return None

    def _convert_to_markdown(self, word_file: str) -> Optional[str]:
        """Convert Word to Markdown using format_converter"""
        result = self.tools['format_converter'].call({
            'file_path': word_file,
            'output_format': 'markdown'
        })
        return result.get('content')

    def _split_chapters(self, md_file: str) -> Optional[List[Dict]]:
        """Split Markdown into chapters using chapter_editor"""
        result = self.tools['chapter_editor'].call({
            'action': 'split',
            'file_path': md_file
        })
        return result.get('chapters')

    def _process_modifications(self, chapters: List[Dict], messages: List[Dict]) -> List[Dict]:
        """Process chapter modifications based on user instructions"""
        # Get modification instructions from last user message
        instructions = next(
            (msg['content'] for msg in reversed(messages) 
             if msg.get('role') == 'user' and 'content' in msg),
            ''
        )
        
        if not instructions:
            return chapters
            
        # Process each chapter
        modified_chapters = []
        for chapter in chapters:
            result = self.tools['chapter_editor'].call({
                'action': 'edit',
                'file_path': chapter['path'],
                'instructions': instructions
            })
            if result.get('status') == 'modified':
                modified_chapters.append(chapter)
                
        return modified_chapters or chapters

    def _merge_chapters(self, chapters: List[Dict]) -> Optional[str]:
        """Merge modified chapters back into single file"""
        if not chapters:
            return None
            
        # Get original file path from first chapter
        original_path = Path(chapters[0]['path']).parent.parent
        merged_path = original_path / 'merged_document.md'
        
        # Merge all chapter contents
        merged_content = []
        for chapter in chapters:
            with open(chapter['path'], 'r', encoding='utf-8') as f:
                merged_content.append(f.read())
                
        # Save merged file
        with open(merged_path, 'w', encoding='utf-8') as f:
            f.write('\n\n'.join(merged_content))
            
        return str(merged_path)

    def _convert_to_word(self, md_file: str) -> Optional[str]:
        """Convert Markdown back to Word using format_converter"""
        result = self.tools['format_converter'].call({
            'file_path': md_file,
            'output_format': 'docx'
        })
        return result.get('output_path')
