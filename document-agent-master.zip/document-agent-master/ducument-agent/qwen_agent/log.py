# Copyright 2023 The Qwen team, Alibaba Group. All rights reserved.
# 
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#    http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import os
import json5
from datetime import datetime


def setup_logger(level=None):
    if level is None:
        if os.getenv('QWEN_AGENT_DEBUG', '0').strip().lower() in ('1', 'true'):
            level = logging.DEBUG
        else:
            level = logging.INFO

    handler = logging.StreamHandler()
    # Do not run handler.setLevel(level) so that users can change the level via logger.setLevel later
    formatter = logging.Formatter('%(asctime)s - %(filename)s - %(lineno)d - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    _logger = logging.getLogger('qwen_agent_logger')
    _logger.setLevel(level)
    _logger.addHandler(handler)
    return _logger


logger = setup_logger()

def log_edit_operation(file_path, operation_type, target=None, new_content=None, line_number=None):
    """记录编辑操作日志"""
    edit_log = {
        'timestamp': datetime.now().isoformat(),
        'file_path': file_path,
        'operation_type': operation_type,
        'target': target,
        'new_content': new_content,
        'line_number': line_number
    }
    
    log_dir = os.path.join(os.getcwd(), 'edit_logs')
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, f"edits_{datetime.now().strftime('%Y%m%d')}.log")
    
    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(json5.dumps(edit_log, ensure_ascii=False) + '\n')


def get_edit_count(file_path=None, operation_type=None):
    """获取指定条件的编辑操作次数
    Args:
        file_path: 筛选文件路径
        operation_type: 筛选操作类型(replace/insert/rewrite)
    """
    log_dir = os.path.join(os.getcwd(), 'edit_logs')
    if not os.path.exists(log_dir):
        return 0
        
    count = 0
    for log_file in os.listdir(log_dir):
        if log_file.startswith('edits_') and log_file.endswith('.log'):
            with open(os.path.join(log_dir, log_file), 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        log_entry = json5.loads(line)
                        match = True
                        if file_path and log_entry['file_path'] != file_path:
                            match = False
                        if operation_type and log_entry['operation_type'] != operation_type:
                            match = False
                        if match:
                            count += 1
                    except:
                        continue
    return count
