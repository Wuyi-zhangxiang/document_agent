# Document Agent 使用说明

## 概述
Document Agent 是一个专业的文档处理智能体，提供Word与Markdown格式互转、Markdown文档拆分编辑合并等功能。

## 工具列表

### 1. MarkdownSplitter - Markdown文档拆分工具
**功能**：按H1标题(#)拆分Markdown文档为多个章节文件

**参数**:
- `file_path` (必填): 待拆分的Markdown文件路径

**输出**:
- 包含各章节文件的列表，每个文件以"序号-章节标题.md"格式命名

**示例**:
```json
{
  "file_path": "document.md"
}
```

### 2. MarkdownEditor - Markdown编辑工具
**功能**：提供多种Markdown编辑操作(替换/插入/重写)

**参数**:
- `file_path` (必填): 待编辑的Markdown文件路径
- `operations` (必填): 编辑操作列表，包含:
  - `type`: 操作类型(replace/insert/rewrite)
  - `target`: 目标位置(章节标题/行号/正则表达式)
  - `content`: 新内容
  - `position`: 插入位置(before/after，仅insert操作需要)

**示例**:
```json
{
  "file_path": "chapter1.md",
  "operations": [
    {
      "type": "replace",
      "target": "旧文本",
      "content": "新文本"
    }
  ]
}
```

### 3. WordToMarkdownTool - Word转Markdown工具
**功能**：转换Word(.docx)为Markdown格式

**参数**:
- `file_path` (必填): Word文档路径
- `output_dir` (可选): 输出目录(默认为当前目录)

**输出**:
- 生成的Markdown文件路径

### 4. MarkdownToWordTool - Markdown转Word工具
**功能**：转换Markdown为Word(.docx)格式

**参数**:
- `file_path` (必填): Markdown文件路径
- `output_dir` (可选): 输出目录(默认为当前目录)

### 5. ChapterMarkdownMerger - Markdown合并工具
**功能**：合并多个Markdown文件

**参数**:
- `file_paths` (必填): 按章节顺序排列的Markdown文件列表
- `output_path` (可选): 输出文件路径(默认为merged.md)

## 典型工作流

1. 将Word初稿转换为Markdown格式
```json
{"file_path": "document.docx"}
```

2. 按章节拆分成多个Markdown文件
```json
{"file_path": "document.md"}
```

3. 编辑各章节内容
```json
{
  "file_path": "01-引言.md",
  "operations": [{
    "type": "replace",
    "target": "旧内容",
    "content": "新内容"
  }]
}
```

4. 合并修改后的Markdown文件
```json
{
  "file_paths": ["01-引言.md", "02-正文.md"],
  "output_path": "merged.md"
}
```

5. 转换回Word格式
```json
{"file_path": "merged.md"}
```

## 注意事项

1. 所有文件路径需使用绝对路径或相对于工作目录的路径
2. 编辑操作会记录到日志中，可通过日志查询历史修改
3. 图片处理需要确保输出目录有写入权限
4. 表格转换会转为Markdown列表格式
